======================
GEARMAN_JOB_QUEUE_FULL
======================

This is a server only error code.
