================
GEARMAN_PIPE_EOF
================

Server only error.
