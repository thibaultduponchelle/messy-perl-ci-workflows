================
Required C types
================

.. highlightlang:: c

Types
-----
  
C Types Used
------------
  
.. c:type:: bool

.. c:type:: uint32_t

.. c:type:: int64_t

.. c:type:: uint64_t

.. c:type:: in_port_t

.. c:type:: size_t

.. c:type:: time_t

.. c:type:: struct timespec

.. c:type:: sasl_callback_t
