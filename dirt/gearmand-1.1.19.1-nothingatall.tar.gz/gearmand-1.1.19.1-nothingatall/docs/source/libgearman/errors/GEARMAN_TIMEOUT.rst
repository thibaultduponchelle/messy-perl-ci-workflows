===============
GEARMAN_TIMEOUT
===============

Please see :c:type:`GEARMAN_TIMEOUT`
