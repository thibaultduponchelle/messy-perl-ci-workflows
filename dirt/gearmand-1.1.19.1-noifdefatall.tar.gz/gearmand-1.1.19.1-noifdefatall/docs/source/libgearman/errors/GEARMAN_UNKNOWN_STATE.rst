=====================
GEARMAN_UNKNOWN_STATE
=====================

Please see :c:type:`GEARMAN_UNKNOWN_STATE`
