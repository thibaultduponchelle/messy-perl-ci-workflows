===============
GEARMAN_NO_JOBS
===============

Please see :c:type:`GEARMAN_NO_JOBS`
