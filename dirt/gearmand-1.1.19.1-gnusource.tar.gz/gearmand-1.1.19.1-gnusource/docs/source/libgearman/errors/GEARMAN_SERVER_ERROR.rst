====================
GEARMAN_SERVER_ERROR
====================

Please see :c:type:`GEARMAN_SERVER_ERROR`
