===============================
GEARMAN_NO_REGISTERED_FUNCTIONS
===============================

Please see :c:type:`GEARMAN_NO_REGISTERED_FUNCTIONS`
