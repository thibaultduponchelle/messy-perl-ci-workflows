===================
GEARMAN_IN_PROGRESS
===================

Please see :c:type:`GEARMAN_IN_PROGRESS`

