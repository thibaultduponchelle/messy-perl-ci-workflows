=================
GEARMAN_WORK_FAIL
=================

Please see :c:type:`GEARMAN_WORK_FAIL`
