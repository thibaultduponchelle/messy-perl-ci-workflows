=============================
GEARMAN_SEND_BUFFER_TOO_SMALL
=============================

Please see :c:type:`GEARMAN_SEND_BUFFER_TOO_SMALL`
