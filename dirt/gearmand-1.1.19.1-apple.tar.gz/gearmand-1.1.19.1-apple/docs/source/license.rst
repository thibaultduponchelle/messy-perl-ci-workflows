=======================
Documentation Licensing
=======================

---------------------
Documentation Content
---------------------

.. image:: cc-symbol.png
   :alt:  Creative Commons License
   :target:  http://creativecommons.org/licenses/by-sa/4.0/

Gearman Documentation (gearman.info) is licensed under a `Attribution-ShareAlike 4.0 International License <http://creativecommons.org/licenses/by-sa/4.0/>`_.

If you need to have the documention licensed in a different manner, please contact `Data Differential <http://www.datadifferential.com/>`_.

------------------------
Server and C/C++ library
------------------------

Gearmand is shipped under the BSD license.
