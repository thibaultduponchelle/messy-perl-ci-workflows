========================
GEARMAN_INVALID_ARGUMENT
========================

Please see :c:type:`GEARMAN_INVALID_ARGUMENT`
