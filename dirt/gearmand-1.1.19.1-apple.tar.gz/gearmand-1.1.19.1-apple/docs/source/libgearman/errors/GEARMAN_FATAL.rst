=============
GEARMAN_FATAL
=============

Please see :c:type:`GEARMAN_FAIL`.  :c:type:`GEARMAN_FATAL` has been deprecated, please use `GEARMAN_FAIL`.

