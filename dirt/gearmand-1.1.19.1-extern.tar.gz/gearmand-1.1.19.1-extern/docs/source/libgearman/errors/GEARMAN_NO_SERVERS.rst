==================
GEARMAN_NO_SERVERS
==================

Please see :c:type:`GEARMAN_NO_SERVERS`
