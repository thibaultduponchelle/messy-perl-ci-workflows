===============================
GEARMAN_INVALID_WORKER_FUNCTION
===============================

Please see :c:type:`GEARMAN_INVALID_WORKER_FUNCTION`
