# Acme-Automatix

This is a toy module just used to test [Github action "upload-to-cpan"](https://github.com/thibaultduponchelle/upload-to-cpan)

The release is *automatix*! :D

## INSTALLATION

To install this module (that actually has no goal), run the following commands:

	perl Makefile.PL
	make
	make test
	make install

## SUPPORT AND DOCUMENTATION

You also look for information at [Acme-Automatix](https://github.com/thibaultduponchelle/Acme-Automatix) or [Github action "upload-to-cpan"](https://github.com/thibaultduponchelle/upload-to-cpan)

## LICENSE AND COPYRIGHT

This software is Copyright (c) 2021 by Thibault Duponchelle.

This is free software, licensed under:

  The Artistic License 2.0 (GPL Compatible)
