=================================
GEARMAN_MEMORY_ALLOCATION_FAILURE
=================================

Please see :c:type:`GEARMAN_MEMORY_ALLOCATION_FAILURE`
