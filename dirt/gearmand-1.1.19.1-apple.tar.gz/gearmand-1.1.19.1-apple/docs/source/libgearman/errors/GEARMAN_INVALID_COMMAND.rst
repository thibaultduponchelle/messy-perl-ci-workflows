=======================
GEARMAN_INVALID_COMMAND
=======================

Please see :c:type:`GEARMAN_INVALID_COMMAND`
