===================
GEARMAN_GETADDRINFO
===================

Please see :c:type:`GEARMAN_GETADDRINFO`
