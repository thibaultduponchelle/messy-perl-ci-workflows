=============
GEARMAN_FATAL
=============

Please see :c:type:`GEARMAN_FATAL`.

